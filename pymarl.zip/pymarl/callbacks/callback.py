
class Callback:

    def __init__(self):
        pass

    def metrics(self, env_data, model_data, **kwargs):
        return {}