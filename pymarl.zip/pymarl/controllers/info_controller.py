from pymarl.modules.agents import REGISTRY as agent_REGISTRY
from pymarl.components.action_selectors import REGISTRY as action_REGISTRY
from pymarl.controllers.basic_controller import BasicMAC
from pymarl.utils.rl_utils import RunningMeanStd
import torch as th
import numpy as np
from torch_geometric.data import Batch

# This multi-agent controller shares parameters between agents and includes the info dict from the environment
class InfoMAC(BasicMAC):
    def __init__(self, scheme, groups, args):
        super().__init__(scheme, groups, args)
        self.existing_keys = set(['state', 'obs', 'actions', 'avail_actions', 'probs', 'reward', 'terminated', 'actions_onehot', 'filled'])
        
    def select_actions(self, ep_batch, t_ep, t_env, bs=slice(None), test_mode=False):
        # Only select actions for the selected batch elements in bs
        avail_actions = ep_batch["avail_actions"][:, t_ep]
        qvals = self.forward(ep_batch, t_ep, test_mode=test_mode)
        chosen_actions = self.action_selector.select_action(qvals[bs], avail_actions[bs], t_env, test_mode=test_mode)
        return chosen_actions

    def build_info(self, batch, t):
        info = {key: val[:,t] for key, val in batch.data.transition_data.items() if key not in self.existing_keys}
        for key, val in info.items():
            if isinstance(val, np.ndarray) and val.dtype=='object':
                info[key] = Batch.from_data_list(val)
        return info

    def forward(self, ep_batch, t, test_mode=False):

        if test_mode:
            self.agent.eval()

        info = self.build_info(ep_batch, t)

        ifexist = info.get("num_users",None)
        if ifexist != None:
            num_users = info.get("num_users",None)
            num_users = num_users[0].item()
            num_uavs = info.get("num_uavs",None)
            num_uavs = num_uavs[0].item()
            #针对obs_user值
            d1 = info.get("obs_user0",None)
            d1 = th.unsqueeze(d1,1)
            for i in range(1,num_users):
                name_user = "obs_user"
                name_id = str(i)
                name_user = name_user + name_id
                d2 = info.get(name_user, None)
                d2 = th.unsqueeze(d2,1)
                d1 = th.cat((d1,d2),dim=1)
            # 针对obs_adj值
            len_adj = num_uavs + num_users
            m1 = info.get("obs_adj0")
            m1 = th.unsqueeze(m1,1)
            for i in range(1,len_adj):
                name_user = "obs_adj"
                name_id = str(i)
                name_user = name_user + name_id
                m2 = info.get(name_user, None)
                m2 = th.unsqueeze(m2,1)
                m1 = th.cat((m1,m2),dim=1)

        d1 = d1.to(th.float32)

        m1 = m1.to(th.float32)

        info1 = {}
        info1["obs_user"] = d1
        
        info1["adj"] = m1

        # inputs_users = info1.get('obs_user',None)

        agent_inputs = self._build_inputs(ep_batch, t)

        avail_actions = ep_batch["avail_actions"][:, t]

        # agent_outs, self.hidden_states = self.agent(agent_inputs, self.hidden_states, info=info)
        agent_outs, self.hidden_states = self.agent(agent_inputs, self.hidden_states, info=info, info1 = info1)
        

        if self.agent_output_type == "pi_logits":
            if getattr(self.args, "mask_before_softmax", True):
                # Make the logits for unavailable actions very negative to minimise their affect on the softmax
                agent_outs = agent_outs.reshape(ep_batch.batch_size, self.n_agents, -1)
                reshaped_avail_actions = avail_actions.reshape(ep_batch.batch_size, self.n_agents, -1)
                agent_outs[reshaped_avail_actions == 0] = -1e10
            agent_outs = th.nn.functional.softmax(agent_outs, dim=-1)

        return agent_outs