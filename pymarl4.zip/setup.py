from setuptools import setup
from setuptools import find_packages

setup(
    name="pymarl",
    version="2.1",
    packages=['pymarl'],
)